# HospitalManagementApp
Angular Applications with appointment booking option with spring boot as backend
